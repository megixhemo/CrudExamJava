package com.crud;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {
	
    public static void main(String[] args) throws Exception{
    	DBConnection obj_DB_connection=new DBConnection();
        System.out.println(obj_DB_connection.get_connection());
    }
    
    
    
    public Connection get_connection() throws Exception{
        Connection connection=null;
        try {
        Class.forName("com.mysql.cj.jdbc.Driver");
        connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/CRUD","root","root");
        } catch (Exception e) {
            System.out.println(e);
        }
        return connection;
    }
}