package com.crud;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Map;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;

@ManagedBean
@RequestScoped

public class Employee {

	private String employee_name;
	private String employee_id;
	private String employee_email;
	private int company_id;
	private int address_id;
	private String company_name;
	private String company_email;
	private String address_city;
	private String address_country;

	public String getEmployee_name() {
		return employee_name;
	}

	public void setEmployee_name(String employee_name) {
		this.employee_name = employee_name;
	}

	public String getEmployee_id() {
		return employee_id;
	}

	public void setEmployee_id(String employee_id) {
		this.employee_id = employee_id;
	}

	public String getEmployee_email() {
		return employee_email;
	}

	public void setEmployee_email(String employee_email) {
		this.employee_email = employee_email;
	}

	public int getCompany_id() {
		return company_id;
	}

	public void setCompany_id(int company_id) {
		this.company_id = company_id;
	}

	public int getAddress_id() {
		return address_id;
	}

	public void setAddress_id(int address_id) {
		this.address_id = address_id;
	}

	public String getCompany_name() {
		return company_name;
	}

	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}

	public String getCompany_email() {
		return company_email;
	}

	public void setCompany_email(String company_email) {
		this.company_email = company_email;
	}

	public String getAddress_city() {
		return address_city;
	}

	public void setAddress_city(String address_city) {
		this.address_city = address_city;
	}

	public String getAddress_country() {
		return address_country;
	}

	public void setAddress_country(String address_country) {
		this.address_country = address_country;
	}

	private Map<String, Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();

	public String edit_Employee() {
		FacesContext fc = FacesContext.getCurrentInstance();
		Map<String, String> params = fc.getExternalContext().getRequestParameterMap();
		String field_id = params.get("action");
		try {
			DBConnection obj_DBConnection = new DBConnection();
			Connection connection = obj_DBConnection.get_connection();
			Statement st = connection.createStatement();
			ResultSet rs = st.executeQuery("select * from employee where employee_id=" + field_id);
			Employee obj_Employee = new Employee();
			rs.next();
			obj_Employee.setEmployee_name(rs.getString("employee_name"));
			obj_Employee.setEmployee_id(rs.getString("employee_id"));
			sessionMap.put("editemployee", obj_Employee);
		} catch (Exception e) {
			System.out.println(e);
		}
		return "/edit.xhtml?faces-redirect=true";
	}

	public String delete_Employee() {
		FacesContext fc = FacesContext.getCurrentInstance();
		Map<String, String> params = fc.getExternalContext().getRequestParameterMap();
		String field_id = params.get("action");
		try {
			DBConnection obj_DBConnection = new DBConnection();
			Connection connection = obj_DBConnection.get_connection();
			PreparedStatement ps = connection.prepareStatement("delete from employee where employee_id=?");
			ps.setString(1, field_id);
			System.out.println(ps);
			ps.executeUpdate();
		} catch (Exception e) {
			System.out.println(e);
		}
		return "/index.xhtml?faces-redirect=true";
	}

	public String update_employee() {
		FacesContext fc = FacesContext.getCurrentInstance();
		Map<String, String> params = fc.getExternalContext().getRequestParameterMap();
		String update_id = params.get("update_id");
		try {
			DBConnection obj_DBConnection = new DBConnection();
			Connection connection = obj_DBConnection.get_connection();
			PreparedStatement ps = connection
					.prepareStatement("update employee set employee_name=? where employee_id=?");
			ps.setString(1, employee_name);
			ps.setString(2, update_id);
			System.out.println(ps);
			ps.executeUpdate();
		} catch (Exception e) {
			System.out.println(e);
		}
		return "/index.xhtml?faces-redirect=true";
	}

	public ArrayList getGet_all_employee() throws Exception {
		ArrayList list_of_employees = new ArrayList();
		Connection connection = null;
		try {
			DBConnection obj_DBConnection = new DBConnection();
			connection = obj_DBConnection.get_connection();
			Statement st = connection.createStatement();
			ResultSet rs = st.executeQuery("select * FROM employee");
			while (rs.next()) {
				Employee obj_Employee = new Employee();
				obj_Employee.setEmployee_id(rs.getString("employee_id"));
				obj_Employee.setCompany_id(rs.getInt(company_id));
				obj_Employee.setAddress_id(rs.getInt(address_id));
				obj_Employee.setEmployee_name(rs.getString("employee_name"));
				obj_Employee.setEmployee_email(rs.getString("employee_email"));
				obj_Employee.setCompany_name(rs.getString("company_name"));
				obj_Employee.setCompany_email(rs.getString("company_email"));
				obj_Employee.setAddress_city(rs.getString("address_city"));
				obj_Employee.setAddress_country(rs.getString("address_country"));

				list_of_employees.add(obj_Employee);
			}
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			if (connection != null) {
				connection.close();
			}
		}
		return list_of_employees;
	}

	public void add_Employee() {
		try {
			Connection connection = null;
			DBConnection obj_DBConnection = new DBConnection();
			connection = obj_DBConnection.get_connection();
			PreparedStatement ps = connection
					.prepareStatement("insert into employee(employee_name) value('" + employee_name + "')");
			ps.executeUpdate();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public Employee() {
	}
}